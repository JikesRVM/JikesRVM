package net.sourceforge.pmd.sourcetypehandlers;

/**
 * Implementation of VisitorStarter that does nothing.
 *
 * @author pieter_van_raemdonck - Application Engineers NV/SA - www.ae.be
 */
public class DummyVisitorStarter implements VisitorStarter {

    public void start(Object rootNode) {
    }

}
