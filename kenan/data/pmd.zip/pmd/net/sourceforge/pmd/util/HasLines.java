package net.sourceforge.pmd.util;

public interface HasLines {
    String getLine(int number);
}
