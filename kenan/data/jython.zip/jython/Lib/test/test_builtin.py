# Python test set -- part 4, built-in functions

from test_support import *

print '4. Built-in functions'

print 'test_b1'
unload('test_b1')
import test_b1

print 'test_b2'
unload('test_b2')
import test_b2
